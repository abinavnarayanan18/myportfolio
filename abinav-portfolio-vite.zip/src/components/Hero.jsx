export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center bg-gradient-to-r from-black to-red">
      <h1 className="text-5xl font-bold">Abinav Narayanan</h1>
      <p className="mt-4 text-xl">Engineering Manager | Product Strategist | DevOps Leader</p>
      <div className="mt-6 flex gap-4">
        <a href="/resume.pdf" className="px-4 py-2 bg-red text-white rounded">View Resume</a>
        <a href="#contact" className="px-4 py-2 border border-white rounded">Contact Me</a>
      </div>
    </section>
  )
}