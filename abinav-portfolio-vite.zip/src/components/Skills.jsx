export default function Skills() {
  return (
    <section className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Skills</h2>
      <p>Product Strategy, AWS, Python, SQL, Excel, Power BI, AI/ML</p>
    </section>
  )
}