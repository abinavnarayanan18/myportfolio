export default function Experience() {
  return (
    <section className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Work Experience</h2>
      <div className="space-y-6">
        <div>
          <h3 className="text-xl font-semibold">EmeraldAI – Student Consultant</h3>
          <p>Aug 2025 – Present</p>
        </div>
        <div>
          <h3 className="text-xl font-semibold">Tata Consultancy Services – Lead DevOps Engineer</h3>
          <p>Jul 2022 – Jul 2025</p>
        </div>
      </div>
    </section>
  )
}