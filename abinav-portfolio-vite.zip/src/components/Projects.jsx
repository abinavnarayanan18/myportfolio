export default function Projects() {
  return (
    <section className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Projects</h2>
      <ul className="space-y-4">
        <li>Smart Visual Assistant for the Visually Impaired (IETE CHENCON 2022)</li>
        <li>AI-Based Satellite Image Restoration (Published 2023)</li>
      </ul>
    </section>
  )
}