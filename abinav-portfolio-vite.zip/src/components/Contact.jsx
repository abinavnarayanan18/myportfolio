export default function Contact() {
  return (
    <section id="contact" className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Contact</h2>
      <p>Email: as1670@duke.edu</p>
      <p>Phone: +1 919-886-0034</p>
      <p>LinkedIn: <a href="https://linkedin.com/in/abinavnarayanan" className="text-red">linkedin.com/in/abinavnarayanan</a></p>
    </section>
  )
}