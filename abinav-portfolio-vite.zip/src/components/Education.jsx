export default function Education() {
  return (
    <section className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Education</h2>
      <ul className="space-y-4">
        <li><strong>Duke University</strong> – MEM (Aug 2025 – Dec 2026 expected)</li>
        <li><strong>Anna University – SSN College of Engineering</strong>, BE in ECE (2018–2022)</li>
      </ul>
    </section>
  )
}