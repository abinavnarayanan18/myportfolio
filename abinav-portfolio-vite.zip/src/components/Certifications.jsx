export default function Certifications() {
  return (
    <section className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Certifications</h2>
      <ul className="space-y-4">
        <li>AWS Certified Solutions Architect – Associate</li>
        <li>AWS Certified DevOps – Professional</li>
        <li>AWS Certified Developer – Associate</li>
      </ul>
    </section>
  )
}