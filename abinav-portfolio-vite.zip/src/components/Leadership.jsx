export default function Leadership() {
  return (
    <section className="max-w-3xl py-20">
      <h2 className="text-3xl font-bold text-red mb-4">Leadership & Community</h2>
      <ul className="space-y-4">
        <li>Co-founder & Mentor – Born To Win Alumni Association</li>
        <li>Core Member – Duke MEM Vibe Coding Club</li>
      </ul>
    </section>
  )
}