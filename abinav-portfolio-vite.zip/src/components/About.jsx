export default function About() {
  return (
    <section className="max-w-3xl py-20 text-center">
      <h2 className="text-3xl font-bold text-red mb-4">About Me</h2>
      <p>I am pursuing a Master of Engineering Management at Duke University, with prior experience as a Lead DevOps Engineer at TCS. 
      My interests lie in engineering management, cloud solutions, and AI-driven innovation.</p>
    </section>
  )
}